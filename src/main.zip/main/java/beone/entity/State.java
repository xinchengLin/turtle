package beone.entity;

public class State {
	private int Camera;
	private int LED;
	private int State;
	public int getCamera() {
		return Camera;
	}
	public void setCamera(int camera) {
		Camera = camera;
	}
	public int getLED() {
		return LED;
	}
	public void setLED(int lED) {
		LED = lED;
	}
	public int getState() {
		return State;
	}
	public void setState(int state) {
		State = state;
	}
	
	

}
