window.onload=function(){
	var AppKey = '952b321600b3453fae7d5435e7e29da2'
	var Secret = 'ae1e6b8f0be161939f3bd9ed5d7656b3'
	$.ajax({
		type:'POST',
		url:'https://open.ys7.com/api/lapp/token/get?',
		dataType:'JSON',
		data:{
			appKey:AppKey,
			appSecret:Secret,
		},
		headers: {
			'Content-Type': 'application/x-www-form-urlencoded'
		},
		success: function(data){
//				console.log(data)
				var accessToken = data.data.accessToken
//				console.log(accessToken)
				$.ajax({
					type:'POST',
					url:'https://open.ys7.com/api/lapp/live/video/list?',
					dataType:'JSON',
					data:{
						accessToken:accessToken,
					},
					success: function(data){
//						console.log(data)
						var rtmp = data.data[0].rtmp
//						console.log(rtmp)
						$('#video-src').attr("src",rtmp)
						console.log($('#video-src')[0].src)
				},
				});
		},
		error:{
			
		},
	});
};

//}