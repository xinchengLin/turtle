function history(){
	   $.ajax({
			type:"GET",
//			url:'http://193.112.11.189:8888/data/pastHour',
			url:'http://193.112.11.189:8888/data/pastHour',
//		   url:'../JSON/data.json',
			dataType: 'json',
		   data:{

		   },
			headers: {

			},
			success: function(data){
//				var div = document.getElementById("canvasB");
//				div.style.cssText='width:500px;height:200px';
//				var vivd = {"time": 1552801636295,"depth": 3,"ph": 7.6,"power": 90.6,"temp": 36.4,"oo": 13.65,"orp": 342.43,"con": 1.6};
				var unixTimestamp = new Date(data.data[0].time) ;
				commonTime = unixTimestamp.toLocaleString();
				console.log(commonTime);
				console.log(data);
				var str = commonTime + '<br/>' +  '电量：' + data.data[0].power + '%' + '<br/>' + 'PH：' + data.data[0].ph + '<br/>' + '温度：' + data.data[0].temp + '℃' + '<br/>' + '深度：' + data.data[0].depth + '（米）' + '<br/>' + '电导率：' + data.data[0].con + '（S/M）' + '<br/>' + '氧化还原电位：' + data.data[0].orp + '（MV）' + '<br/>' + '溶解氧：' + data.data[0].oo + '（Mg/L）' + '<br/>' 
				$('#history').html(str);
				
				var barChartData = {
						labels : ["过去","","","","","","现在"],
						datasets : [
							{
								fillColor : "rgba(220,220,220,0.5)",
								strokeColor : "rgba(220,220,220,1)",
								data : [7.6,7.6,7.6,7.6,7.6,7.6,7.6],
							},
							{
								fillColor : "rgba(151,187,205,0.5)",
								strokeColor : "rgba(151,187,205,1)",
								data : [36.4,36.5,36.4,36.4,36.4,36.4,36.4],
							}
						]

					};
					var myLine = new Chart(document.getElementById("canvasB").getContext("2d")).Bar(barChartData);

				
//				var historyPh = [];
//				var historyTemp = [];
//				for(var i=0; i<7; i++){
//					var strPh = data.data[i].ph;
//					var strTemp = data.data[i].temp;
//					historyPh.push(strPh);
//					historyTemp.push(strTemp);
//					
//					var barChartData = {
//						labels : ["过去","","","","","","现在"],
//						datasets : [
//							{
//								fillColor : "rgba(220,220,220,0.5)",
//								strokeColor : "rgba(220,220,220,1)",
//								data : historyPh,
//							},
//							{
//								fillColor : "rgba(151,187,205,0.5)",
//								strokeColor : "rgba(151,187,205,1)",
//								data : historyTemp,
//							}
//						]
//
//					};
//					var myLine = new Chart(document.getElementById("canvasB").getContext("2d")).Bar(barChartData);
//
//				}
				
		
			}, 
			error: function(data){
				console.log(data);

			}
		});
	}

var barChartData = {
	labels : ["过去","","","","","","现在"],
	datasets : [
		{
			fillColor : "rgba(220,220,220,0.5)",
			strokeColor : "rgba(220,220,220,1)",
			data : [7.38,7.39,7.46,7.50,7.42,7.45,7.43]
		},
		{
			fillColor : "rgba(151,187,205,0.5)",
			strokeColor : "rgba(151,187,205,1)",
			data : [23,23,24,26,23,24,21]
		}
	]

};
var myLine = new Chart(document.getElementById("canvasB").getContext("2d")).Bar(barChartData);

var lineChartData = {
	labels : ["1 MON","2 TUE","3 WED","4 THU","5 FRI","6 SAT","7 SUN"],
	datasets : [
		{
			fillColor : "rgba(151,187,205,0.5)",
			strokeColor : "rgba(237,90,92,0.5)",
			pointColor : "rgba(237,90,92,0.5)",
			pointStrokeColor : "#fff",
			data : [7.38,7.39,7.46,7.50,7.42,7.45,7.43]
		}
	]

}

var myLine = new Chart(document.getElementById("canvas").getContext("2d")).Line(lineChartData);

function Ph(){
	$('#canvas').remove();
	$('#remove-canvas').append('<canvas id="canvas" width="500px" height="200px"></canvas>');
	$('#canvas').css({"background":"none"});
	var lineChartData = {
		labels : ["1 MON","2 TUE","3 WED","4 THU","5 FRI","6 SAT","7 SUN"],
		datasets : [
			{
				fillColor : "rgba(151,187,205,0.5)",
				strokeColor : "rgba(237,90,92,0.5)",
				pointColor : "rgba(237,90,92,0.5)",
				pointStrokeColor : "#fff",
				data : [7.38,7.39,7.46,7.50,7.42,7.45,7.43]
			}
		]

	}

	var myLine = new Chart(document.getElementById("canvas").getContext("2d")).Line(lineChartData);
}
function Temp(){
$('#canvas').remove();
$('#remove-canvas').append('<canvas id="canvas" width="500px" height="200px"></canvas>');
$('#canvas').css({"background":"none"});
var lineChartData = {
	labels : ["1 MON","2 TUE","3 WED","4 THU","5 FRI","6 SAT","7 SUN"],
	datasets : [
		{
			fillColor : "rgba(220,220,220,0.5)",
			strokeColor : "rgba(97,190,243,0.5)",
			pointColor : "rgba(97,190,243,0.5)",
			pointStrokeColor : "#fff",
			data : [23,23,24,26,23,24,21]
		}
	]

}
var myLine = new Chart(document.getElementById("canvas").getContext("2d")).Line(lineChartData);
};
