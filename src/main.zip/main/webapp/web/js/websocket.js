//{"time":1552658481575,"Power": 100.0,"Temp":36.0, "Depth":3.0, "PH":7.0,"OO":56.0,"CON":324.0,"ORP":133.0}
//console.log(abc);
//$('#websocketData').html('');
//	var apr = '电量：' + abc.Power + '<br/>' + '温度:' + abc.Temp + '<br/>' + '深度：' + abc.Depth + '<br/>' + 'PH：' + abc.PH + '<br/>' + 'OO：' + abc.OO + '<br/>' + 'CON：' + abc.CON + '<br/>' + 'ORP：' + abc.ORP + '<br/>'
//	console.log(apr)
//	$('#websocketData').html(apr);


var websocket = null;

    //判断当前浏览器是否支持WebSocket
    if('WebSocket' in window){
        websocket = new WebSocket("ws://192.168.31.8:8888/getServer");
//        websocket = new WebSocket("ws://192.168.31.8:8888/getServer");
    }
    else{
        alert('Not support websocket')
    }

    //连接发生错误的回调方法
    websocket.onerror = function(){
//        setMessageInnerHTML("error");
    };

    //连接成功建立的回调方法
    websocket.onopen = function(event){
//        setMessageInnerHTML("open");
    }
//$('#websocketData').html('');
    //接收到消息的回调方法
    websocket.onmessage = function(event){
//        setMessageInnerHTML(event.data);
//		console.log(event.data)
//		console.log(JSON.parse(event.data))
		var apr = JSON.parse(event.data);
//		console.log(apr)
		$('#websocketData').html('');
		var time = apr.time
//		console.log(time)
		var unixTimestamp = new Date(time) ;
		commonTime = unixTimestamp.toLocaleString();
		console.log(commonTime)
		
		var apr = commonTime + '<br/>' + '电量：' + apr.Power + '%' + '<br/>' + 'PH：' + apr.PH + '<br/>' + '温度：' + apr.Temp + '℃' + '<br/>' + '深度：' + apr.Depth + '（米）' + '<br/>' + '电导率：' + apr.CON + '（S/M）' + '<br/>' + '氧化还原电位：' + apr.ORP + '（MV）' + '<br/>' + '溶解氧：' + apr.OO + '（Mg/L）' + '<br/>' 
//		console.log(apr)
		$('#websocketData').html(apr);
	};

    //连接关闭的回调方法
    websocket.onclose = function(){
//        setMessageInnerHTML("close");
    }

    //监听窗口关闭事件，当窗口关闭时，主动去关闭websocket连接，防止连接还没断开就关闭窗口，server端会抛异常。
    window.onbeforeunload = function(){
        websocket.close();
    }

    //将消息显示在网页上
    function setMessageInnerHTML(innerHTML){
//        document.getElementById('data').innerHTML += innerHTML + '<br/>';
    }

    //关闭连接
    function closeWebSocket(){
        websocket.close();
    }

//    //发送消息
//    function send(){
//        var message = document.getElementById('text').value;
//        websocket.send(message);
//    }
	//mo ni shuju 视频
//	var vidi = {"code":200,"msg":"成功获取","data":"rtmp://rtmp.open.ys7.com/openlive/e0f4707fa92c484cbd4e4ad31c074bd3"};
//	console.log(vidi);
//	$('#video-src')[0].src=vidi.data;
//	console.log($('#video-src')[0].src)
